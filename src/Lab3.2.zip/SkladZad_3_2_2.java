public class SkladZad_3_2_2 {
    int height;
    int weight;
    int depth;
}
